import xmlrpc.client
import tkinter as tk
from tkinter import ttk

class StockUpdaterGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Mise à jour du stock")
        self.create_widgets()

    def create_widgets(self):
        # Tableau pour afficher les informations sur les articles
        self.tree = ttk.Treeview(self.master, columns=("Nom", "Référence", "Prix", "Quantité en stock"))
        self.tree.heading("#0", text="ID")
        self.tree.heading("Nom", text="Nom de l'article")
        self.tree.heading("Référence", text="Référence")
        self.tree.heading("Prix", text="Prix")
        self.tree.heading("Quantité en stock", text="Quantité en stock")
        self.tree.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky=tk.W)

        # Connexion à Odoo
        url = "http://localhost:8069"
        db = "SOUMSOUMv2"
        username = "melvyndupas01@gmail.com"
        password = "123456789"

        common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
        uid = common.authenticate(db, username, password, {})
        models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))

        # Récupérer les informations sur les articles depuis Odoo
        articles = models.execute_kw(db, uid, password, 'product.template', 'search_read', [], {'fields': ['id', 'name', 'default_code', 'list_price', 'qty_available']})

        # Remplir le tableau avec les informations récupérées
        for article in articles:
            self.tree.insert("", tk.END, text=article['id'], values=(article['name'], article['default_code'], "${:.2f}".format(article['list_price']), article['qty_available']))

        self.label_ref = ttk.Label(self.master, text="Référence de l'article:")
        self.label_ref.grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)

        self.entry_ref = ttk.Entry(self.master)
        self.entry_ref.grid(row=1, column=1, padx=10, pady=10)

        self.label_quantity = ttk.Label(self.master, text="Nouvelle quantité:")
        self.label_quantity.grid(row=2, column=0, padx=10, pady=10, sticky=tk.W)

        self.entry_quantity = ttk.Entry(self.master)
        self.entry_quantity.grid(row=2, column=1, padx=10, pady=10)

        self.button_update = ttk.Button(self.master, text="Mettre à jour le stock", command=self.update_stock)
        self.button_update.grid(row=3, column=0, columnspan=2, pady=20)

    def update_stock(self):
        article_default_code = self.entry_ref.get()
        new_quantity = int(self.entry_quantity.get())

        # Connexion à Odoo
        url = "http://localhost:8069"
        db = "SOUMSOUMv2"
        username = "melvyndupas01@gmail.com"
        password = "123456789"

        common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
        uid = common.authenticate(db, username, password, {})
        models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))

        # Recherche de l'ID de l'article par la référence interne
        article_id = models.execute_kw(db, uid, password, 'product.template', 'search', [[('default_code', '=', article_default_code)]])
        
        if article_id:
            # Rechercher les entrées du modèle stock.quant associées à l'article
            stock_entries = models.execute_kw(db, uid, password, 'stock.quant', 'search_read', [
                [('product_id', '=', article_id[0])]
            ])

            if stock_entries:
                # Mettre à jour la quantité en remplaçant par la nouvelle quantité
                new_stock_quantity = new_quantity

                # Mettre à jour la stock.quant associée à l'article
                models.execute_kw(db, uid, password, 'stock.quant', 'write', [stock_entries[0]['id'], {'quantity': new_stock_quantity}])
                print("Quantité en stock mise à jour avec succès.")

                # Réinitialiser la fenêtre après la mise à jour
                self.master.destroy()
                root = tk.Tk()
                app = StockUpdaterGUI(root)
                root.mainloop()
            else:
                print("Aucune entrée stock.quant trouvée pour l'article.")
        else:
            print("Article non trouvé.")

def main():
    root = tk.Tk()
    app = StockUpdaterGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()